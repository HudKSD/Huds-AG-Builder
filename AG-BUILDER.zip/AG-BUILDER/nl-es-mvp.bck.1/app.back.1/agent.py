import json
import re
from typing import Any, Dict, List, Tuple, Optional

from .llm_client import OpenAICompatibleClient, LLMError
from .conversation_store import ConversationStore
from .tools.registry import ToolRegistry

SYSTEM_PROMPT = """You are an Elasticsearch SOC data assistant.

You MUST use discovered schema and real Elasticsearch results.
Do NOT invent fields or results.

Rules:
- Schema-first is mandatory (we always fetch mappings/field_caps before searching).
- Never assume fields like 'cve_id' or '@timestamp' exist.
- Use type-aware logic:
  - term/terms on keyword-like fields
  - match/match_phrase on text fields
  - for aggregations, prefer '.keyword' when present
- Always apply a time window if possible, but if no results: escalate with fallback ladder.
- When done, answer with:
  1) 2–6 bullets of findings
  2) show assumptions/filters (time field used, time range, index pattern)
"""

PLANNER_PROMPT = """You are a STRICT Elasticsearch query planner.

Return ONLY valid JSON (no markdown, no commentary).
Use ONLY fields present in schema.sample_fields / schema.cve_fields / schema.message_fields / schema.date_fields.
If unsure about exact fields, prefer text_query (do NOT guess field names).

Plan JSON schema:
{
  "pattern": "<MUST equal schema.pattern>",
  "mode": "search" | "aggregate",
  "limit": <int 1..200>,
  "include_older_if_none": true | false,

  "time": {
    "enabled": true | false,
    "field": "<optional date field>",
    "from": "<date math or ISO, e.g. now-30d>",
    "to": "<date math or ISO, e.g. now>"
  },

  "filters": [
    {"field": "<field>", "op": "eq|neq|contains|match|match_phrase|gt|gte|lt|lte|exists|in", "value": "<string|number|bool|array>"}
  ],

  "text_query": "<optional string>",
  "text_fields": ["<optional field list>"],

  "group_by": "<field for aggregate (optional)>",
  "metric": {"fn": "count|sum|avg|min|max", "field": "<optional>"}
}

Guidance:
- If user asks for a specific indicator (CVE/IP/hash/domain), set mode="search" and set text_query to that indicator.
- If user asks "top X by Y" or "count/group", use mode="aggregate".
"""

# ---- Context safety limits ----
MAX_CONTEXT_CHARS = 180_000
MAX_TOOL_MESSAGE_CHARS = 12_000
MAX_TABLE_ROWS_FOR_LLM = 20
MAX_CELL_CHARS = 200
MAX_DICT_KEYS = 20
MAX_LIST_ITEMS = 30


def _clip_text(s: str, n: int) -> str:
    s = s if s is not None else ""
    return s if len(s) <= n else s[:n] + "…(truncated)"


def _clip_any(v: Any) -> Any:
    if v is None:
        return None
    if isinstance(v, str):
        return _clip_text(v, 2000)
    if isinstance(v, (int, float, bool)):
        return v
    if isinstance(v, list):
        out = [_clip_any(x) for x in v[:MAX_LIST_ITEMS]]
        if len(v) > MAX_LIST_ITEMS:
            out.append(f"…(truncated {len(v) - MAX_LIST_ITEMS} items)")
        return out
    if isinstance(v, dict):
        keys = list(v.keys())[:MAX_DICT_KEYS]
        out = {k: _clip_any(v[k]) for k in keys}
        if len(v) > MAX_DICT_KEYS:
            out["…"] = f"(truncated {len(v) - MAX_DICT_KEYS} keys)"
        return out
    return _clip_text(str(v), 2000)


def _sanitize_tool_result(tool_name: str, result: Any) -> Any:
    # preserve errors
    if isinstance(result, dict) and "error" in result:
        return {"error": _clip_text(str(result["error"]), 2000)}

    if not isinstance(result, dict):
        return _clip_any(result)

    if tool_name == "esql_query":
        cols = (result.get("columns") or [])[:60]
        rows = (result.get("rows") or [])[:MAX_TABLE_ROWS_FOR_LLM]
        safe_rows = []
        for r in rows:
            rr = []
            for cell in (r or [])[:len(cols)]:
                if cell is None:
                    rr.append(None)
                else:
                    s = str(cell)
                    rr.append(s if len(s) <= MAX_CELL_CHARS else s[:MAX_CELL_CHARS] + "…")
            safe_rows.append(rr)
        return {
            "query": _clip_text(result.get("query", ""), 4000),
            "filter": _clip_any(result.get("filter")),
            "time_field_used": result.get("time_field_used"),
            "took": result.get("took"),
            "columns": cols,
            "rows": safe_rows,
            "row_count": len(safe_rows),
        }

    if tool_name == "dsl_search":
        hits = (result.get("hits") or [])[:10]
        out_hits = []
        for h in hits:
            src = h.get("_source")
            if isinstance(src, dict):
                keys = list(src.keys())[:12]
                src_small = {k: _clip_any(src[k]) for k in keys}
                if len(src) > 12:
                    src_small["…"] = f"(truncated {len(src) - 12} keys)"
            else:
                src_small = _clip_text(str(src), 2000)

            out_hits.append({
                "_index": h.get("_index"),
                "_id": h.get("_id"),
                "_score": h.get("_score"),
                "_source": src_small,
            })

        return {
            "index": result.get("index"),
            "dsl": _clip_any(result.get("dsl")),
            "count": len(out_hits),
            "hits": out_hits,
            "stage": result.get("stage"),
            "time_field_used": result.get("time_field_used"),
        }

    if tool_name == "get_mappings":
        return {
            "pattern": result.get("pattern"),
            "field_count": result.get("field_count"),
            "preferred_time_field": result.get("preferred_time_field"),
            "date_fields": (result.get("date_fields") or [])[:30],
            "cve_fields": (result.get("cve_fields") or [])[:80],
            "message_fields": (result.get("message_fields") or [])[:40],
            "sample_fields": (result.get("sample_fields") or [])[:220],
            "field_caps": (result.get("field_caps") or {}),
        }

    if tool_name == "list_indices":
        inds = (result.get("indices") or [])[:100]
        return {"pattern": result.get("pattern"), "count": len(inds), "indices": inds}

    if tool_name == "get_doc":
        src = result.get("_source")
        if isinstance(src, dict):
            keys = list(src.keys())[:20]
            src_small = {k: _clip_any(src[k]) for k in keys}
            if len(src) > 20:
                src_small["…"] = f"(truncated {len(src) - 20} keys)"
        else:
            src_small = _clip_text(str(src), 4000)
        return {"_index": result.get("_index"), "_id": result.get("_id"), "_source": src_small}

    return _clip_any(result)


def _message_size(m: Dict[str, Any]) -> int:
    s = ""
    if "content" in m and isinstance(m["content"], str):
        s += m["content"]
    if "tool_calls" in m:
        s += json.dumps(m["tool_calls"], ensure_ascii=False)
    return len(s)


def _chunk_for_tool_calls(rest: List[Dict[str, Any]]) -> List[List[Dict[str, Any]]]:
    """
    Create blocks so we never keep a tool message without its preceding assistant tool_calls.
    Blocks:
      - assistant(with tool_calls) + following tool messages
      - otherwise, each message alone
    """
    blocks: List[List[Dict[str, Any]]] = []
    i = 0
    while i < len(rest):
        m = rest[i]
        if m.get("role") == "assistant" and m.get("tool_calls"):
            block = [m]
            i += 1
            while i < len(rest) and rest[i].get("role") == "tool":
                block.append(rest[i])
                i += 1
            blocks.append(block)
        else:
            blocks.append([m])
            i += 1
    return blocks


def _repair_orphan_tool_messages(msgs: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    If a tool message exists without an immediately preceding assistant tool_calls,
    convert it to a normal 'assistant' message to avoid OpenAI 400.
    """
    out: List[Dict[str, Any]] = []
    for m in msgs:
        if m.get("role") == "tool":
            if not out or out[-1].get("role") != "assistant" or not out[-1].get("tool_calls"):
                out.append({"role": "assistant", "content": f"[orphan_tool_output]\n{m.get('content','')}"})
            else:
                out.append(m)
        else:
            out.append(m)
    return out


def _trim_context(messages: List[Dict[str, Any]], max_chars: int = MAX_CONTEXT_CHARS) -> List[Dict[str, Any]]:
    if not messages:
        return messages

    system = messages[0] if messages[0].get("role") == "system" else None
    rest = messages[1:] if system else messages[:]

    blocks = _chunk_for_tool_calls(rest)

    kept_blocks: List[List[Dict[str, Any]]] = []
    total = _message_size(system) if system else 0

    for block in reversed(blocks):
        block_size = sum(_message_size(m) for m in block)
        if total + block_size > max_chars and kept_blocks:
            break
        if total + block_size > max_chars and not kept_blocks:
            # keep at least this last block, but clip its contents
            clipped = []
            for mm in block:
                m2 = dict(mm)
                if isinstance(m2.get("content"), str):
                    m2["content"] = _clip_text(m2["content"], max_chars // 6)
                clipped.append(m2)
            kept_blocks.append(clipped)
            total += sum(_message_size(m) for m in clipped)
            break

        kept_blocks.append(block)
        total += block_size

    kept_blocks.reverse()
    flattened: List[Dict[str, Any]] = []
    for b in kept_blocks:
        flattened.extend(b)

    final_msgs = ([system] + flattened) if system else flattened
    return _repair_orphan_tool_messages(final_msgs)


def _extract_tool_calls(msg: Dict[str, Any]) -> List[Dict[str, Any]]:
    tc = msg.get("tool_calls")
    if isinstance(tc, list):
        return tc
    fc = msg.get("function_call")
    if fc and isinstance(fc, dict):
        return [{
            "id": "legacy",
            "type": "function",
            "function": {"name": fc.get("name"), "arguments": fc.get("arguments", "{}")}
        }]
    return []


# Indicator detection
CVE_RE = re.compile(r"\bCVE-\d{4}-\d{4,7}\b", re.IGNORECASE)
IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
MD5_RE = re.compile(r"\b[a-fA-F0-9]{32}\b")
SHA1_RE = re.compile(r"\b[a-fA-F0-9]{40}\b")
SHA256_RE = re.compile(r"\b[a-fA-F0-9]{64}\b")
DOMAIN_RE = re.compile(r"\b(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}\b")


def _detect_indicator(text: str) -> Optional[Dict[str, str]]:
    t = text.strip()
    m = CVE_RE.search(t)
    if m:
        return {"type": "cve", "value": m.group(0).upper()}
    m = SHA256_RE.search(t)
    if m:
        return {"type": "sha256", "value": m.group(0).lower()}
    m = SHA1_RE.search(t)
    if m:
        return {"type": "sha1", "value": m.group(0).lower()}
    m = MD5_RE.search(t)
    if m:
        return {"type": "md5", "value": m.group(0).lower()}
    m = IP_RE.search(t)
    if m:
        return {"type": "ip", "value": m.group(0)}
    m = DOMAIN_RE.search(t)
    if m and " " not in m.group(0):
        return {"type": "domain", "value": m.group(0).lower()}
    return None


def _extract_time_window(text: str) -> Tuple[Optional[str], Optional[str]]:
    t = text.lower()
    if "last week" in t or "past week" in t:
        return ("now-7d", "now")
    if "last month" in t or "past month" in t:
        return ("now-30d", "now")
    if "last year" in t or "past year" in t:
        return ("now-365d", "now")

    m = re.search(r"(last|past)\s+(\d+)\s*(day|days|d)\b", t)
    if m:
        return (f"now-{int(m.group(2))}d", "now")
    m = re.search(r"(last|past)\s+(\d+)\s*(hour|hours|h)\b", t)
    if m:
        return (f"now-{int(m.group(2))}h", "now")
    m = re.search(r"(last|past)\s+(\d+)\s*(minute|minutes|min|mins|m)\b", t)
    if m:
        return (f"now-{int(m.group(2))}m", "now")

    return (None, None)


# Type-aware helpers (simple)
NUMERIC_TYPES = {"byte", "short", "integer", "long", "half_float", "float", "double", "scaled_float", "unsigned_long"}
KEYWORD_TYPES = {"keyword", "ip", "boolean"}
TEXT_TYPES = {"text", "match_only_text", "wildcard"}


def _norm_field(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", (s or "").lower())


def _resolve_field(name: str, fields_map: Dict[str, str]) -> Optional[str]:
    if not name:
        return None
    n = name.strip()
    if n in fields_map:
        return n
    if n.endswith(".keyword") and n[:-8] in fields_map:
        return n[:-8]
    if (n + ".keyword") in fields_map:
        return n + ".keyword"
    alt = n.replace("_", ".")
    if alt in fields_map:
        return alt
    if (alt + ".keyword") in fields_map:
        return alt + ".keyword"
    nn = _norm_field(n)
    for f in fields_map.keys():
        if _norm_field(f) == nn:
            return f
    return None


def _prefer_keyword(field: str, fields_map: Dict[str, str]) -> str:
    if field in fields_map and fields_map[field] in TEXT_TYPES:
        kw = field + ".keyword"
        if kw in fields_map and fields_map[kw] == "keyword":
            return kw
    return field


def _make_clause(field: str, op: str, value: Any, fields_map: Dict[str, str]) -> Optional[Dict[str, Any]]:
    f = _resolve_field(field, fields_map)
    if not f:
        return None
    ftype = fields_map.get(f, "object")

    if op == "exists":
        return {"exists": {"field": f}}

    if op in ("gt", "gte", "lt", "lte"):
        if ftype in NUMERIC_TYPES or ftype in ("date", "date_nanos"):
            return {"range": {f: {op: value}}}
        return None

    if op == "in":
        if not isinstance(value, list):
            return None
        ff = _prefer_keyword(f, fields_map) if fields_map.get(f) in TEXT_TYPES else f
        return {"terms": {ff: value}}

    if op in ("eq", "neq"):
        ff = _prefer_keyword(f, fields_map) if fields_map.get(f) in TEXT_TYPES else f
        if fields_map.get(ff) == "keyword" or fields_map.get(ff) in KEYWORD_TYPES or fields_map.get(ff) in NUMERIC_TYPES or fields_map.get(ff) in ("date", "date_nanos"):
            clause = {"term": {ff: value}}
        else:
            clause = {"match_phrase": {f: {"query": str(value)}}}
        if op == "neq":
            return {"bool": {"must_not": [clause]}}
        return clause

    if op == "contains":
        if ftype == "keyword" or ftype in KEYWORD_TYPES:
            return {"wildcard": {f: {"value": f"*{value}*", "case_insensitive": True}}}
        return {"match": {f: {"query": str(value), "operator": "and"}}}

    if op == "match":
        return {"match": {f: {"query": str(value), "operator": "and"}}}

    if op == "match_phrase":
        return {"match_phrase": {f: {"query": str(value)}}}

    return None


def _extract_json_object(text: str) -> Optional[Dict[str, Any]]:
    if not text:
        return None
    text = text.strip()
    try:
        return json.loads(text)
    except Exception:
        pass
    m = re.search(r"\{.*\}", text, flags=re.DOTALL)
    if not m:
        return None
    try:
        return json.loads(m.group(0))
    except Exception:
        return None


async def _pick_time_field_by_probe(agent: "NL2ESAgent", index: str, candidates: List[str], gte: str, lte: str) -> Optional[str]:
    es = agent.tools.ctx.es
    for f in candidates[:12]:
        try:
            r = await es.count(index=index, query={"range": {f: {"gte": gte, "lte": lte}}})
            if (r or {}).get("count", 0) > 0:
                return f
        except Exception:
            continue
    return candidates[0] if candidates else None


class NL2ESAgent:
    def __init__(self, llm: OpenAICompatibleClient, tools: ToolRegistry, store: ConversationStore, max_steps: int = 8):
        self.llm = llm
        self.tools = tools
        self.store = store
        self.max_steps = max_steps

    async def _schema_first(self, messages: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], Dict[str, Any], str, List[Dict[str, Any]]]:
        trace: List[Dict[str, Any]] = []
        allowed = self.tools.ctx.settings.es_allowed_patterns

        schema_prompt = (
            "MANDATORY STEP (schema-first): Choose ONE best index pattern from this allowlist:\n"
            f"{allowed}\n"
            "Then CALL get_mappings(pattern=<chosen pattern>) EXACTLY ONCE.\n"
            "Do NOT call any other tool in this step."
        )

        only_get_mappings = [t for t in self.tools.schemas() if (t.get("function") or {}).get("name") == "get_mappings"]

        schema_messages = _trim_context(messages + [{"role": "system", "content": schema_prompt}], max_chars=90_000)

        resp = await self.llm.chat(messages=schema_messages, tools=only_get_mappings, tool_choice="auto")
        msg = (resp.get("choices") or [{}])[0].get("message") or {}
        tool_calls = _extract_tool_calls(msg)

        if not tool_calls or (tool_calls[0].get("function") or {}).get("name") != "get_mappings":
            tool_calls = [{
                "id": "schema0",
                "type": "function",
                "function": {"name": "get_mappings", "arguments": json.dumps({"pattern": allowed[0], "max_fields": 400})}
            }]
            messages.append({"role": "assistant", "content": "", "tool_calls": tool_calls})
            selected_pattern = allowed[0]
        else:
            messages.append({"role": "assistant", "content": msg.get("content") or "", "tool_calls": tool_calls})
            try:
                args = json.loads((tool_calls[0].get("function") or {}).get("arguments") or "{}")
            except Exception:
                args = {"pattern": allowed[0], "max_fields": 400}
            selected_pattern = (args.get("pattern") or allowed[0]).strip()

        # execute get_mappings
        fn = tool_calls[0]["function"]
        try:
            args = json.loads(fn.get("arguments") or "{}")
        except Exception:
            args = {"pattern": selected_pattern, "max_fields": 400}

        result_full = await self.tools.run("get_mappings", args)
        result_small = _sanitize_tool_result("get_mappings", result_full)
        tool_content = _clip_text(json.dumps(result_small, ensure_ascii=False), MAX_TOOL_MESSAGE_CHARS)

        # tool message is valid because it follows assistant(tool_calls)
        messages.append({"role": "tool", "tool_call_id": tool_calls[0].get("id", "schema0"), "content": tool_content})

        trace.append({"step": "schema_first", "pattern": selected_pattern})
        return messages, result_small, selected_pattern, trace

    async def _plan(self, user_text: str, schema_small: Dict[str, Any], pattern: str) -> Dict[str, Any]:
        indicator = _detect_indicator(user_text)
        t_from, t_to = _extract_time_window(user_text)

        if indicator:
            return {
                "pattern": pattern,
                "mode": "search",
                "limit": min(10, self.tools.ctx.settings.row_limit),
                "include_older_if_none": True,
                "time": {
                    "enabled": True,
                    "field": schema_small.get("preferred_time_field") or None,
                    "from": t_from or self.tools.ctx.settings.default_time_from,
                    "to": t_to or self.tools.ctx.settings.default_time_to,
                },
                "filters": [],
                "text_query": indicator["value"],
                "text_fields": [],
            }

        planner_messages = [
            {"role": "system", "content": PLANNER_PROMPT},
            {"role": "user", "content": json.dumps({"question": user_text, "schema": schema_small}, ensure_ascii=False)}
        ]
        resp = await self.llm.chat(messages=_trim_context(planner_messages, max_chars=90_000))
        msg = (resp.get("choices") or [{}])[0].get("message") or {}
        plan_obj = _extract_json_object(msg.get("content") or "")

        if not isinstance(plan_obj, dict):
            plan_obj = {
                "pattern": pattern,
                "mode": "search",
                "limit": min(10, self.tools.ctx.settings.row_limit),
                "include_older_if_none": True,
                "time": {
                    "enabled": True,
                    "field": schema_small.get("preferred_time_field") or None,
                    "from": t_from or self.tools.ctx.settings.default_time_from,
                    "to": t_to or self.tools.ctx.settings.default_time_to,
                },
                "filters": [],
                "text_query": user_text,
                "text_fields": [],
            }

        plan_obj["pattern"] = pattern
        plan_obj.setdefault("mode", "search")
        plan_obj.setdefault("filters", [])
        plan_obj.setdefault("include_older_if_none", True)
        plan_obj.setdefault("limit", min(10, self.tools.ctx.settings.row_limit))
        plan_obj["limit"] = max(1, min(int(plan_obj["limit"]), self.tools.ctx.settings.row_limit))

        if "time" not in plan_obj or not isinstance(plan_obj["time"], dict):
            plan_obj["time"] = {
                "enabled": True,
                "field": schema_small.get("preferred_time_field"),
                "from": self.tools.ctx.settings.default_time_from,
                "to": self.tools.ctx.settings.default_time_to,
            }
        else:
            plan_obj["time"].setdefault("enabled", True)
            plan_obj["time"].setdefault("field", schema_small.get("preferred_time_field"))
            plan_obj["time"].setdefault("from", self.tools.ctx.settings.default_time_from)
            plan_obj["time"].setdefault("to", self.tools.ctx.settings.default_time_to)

        # respect explicit time phrases if present
        tt_from, tt_to = _extract_time_window(user_text)
        if tt_from:
            plan_obj["time"]["from"] = tt_from
        if tt_to:
            plan_obj["time"]["to"] = tt_to

        return plan_obj

    async def _execute_with_fallback(self, pattern: str, plan: Dict[str, Any], schema_small: Dict[str, Any]) -> Dict[str, Any]:
        fields_map, date_fields = await self.tools.ctx.schema_cache.get_flat_fields(pattern)

        time_cfg = plan.get("time") or {}
        time_enabled = bool(time_cfg.get("enabled", True))
        time_from = time_cfg.get("from") or self.tools.ctx.settings.default_time_from
        time_to = time_cfg.get("to") or self.tools.ctx.settings.default_time_to

        requested_time_field = _resolve_field(str(time_cfg.get("field") or ""), fields_map) if time_cfg.get("field") else None
        if requested_time_field and fields_map.get(requested_time_field) not in ("date", "date_nanos"):
            requested_time_field = None

        time_field = requested_time_field or schema_small.get("preferred_time_field")
        if time_field and fields_map.get(time_field) not in ("date", "date_nanos"):
            time_field = None

        if time_enabled:
            time_field = time_field or await _pick_time_field_by_probe(self, pattern, date_fields, time_from, time_to)

        cve_fields = [f for f in (schema_small.get("cve_fields") or []) if f in fields_map]
        msg_fields = [f for f in (schema_small.get("message_fields") or []) if f in fields_map]
        if not msg_fields:
            msg_fields = [f for f, t in fields_map.items() if t in TEXT_TYPES][:25]

        limit = int(plan.get("limit") or 10)
        include_older = bool(plan.get("include_older_if_none", True))
        text_query = (plan.get("text_query") or "").strip()

        must: List[Dict[str, Any]] = []
        must_not: List[Dict[str, Any]] = []
        filters = plan.get("filters") or []

        for f in filters:
            if not isinstance(f, dict):
                continue
            field = str(f.get("field") or "").strip()
            op = str(f.get("op") or "eq").strip()
            value = f.get("value")
            clause = _make_clause(field, op, value, fields_map)
            if clause is None:
                continue
            if op == "neq" and "bool" in clause and "must_not" in clause["bool"]:
                must_not.extend(clause["bool"]["must_not"])
            else:
                must.append(clause)

        filter_list: List[Dict[str, Any]] = []
        if time_enabled and time_field:
            filter_list.append({"range": {time_field: {"gte": time_from, "lte": time_to}}})

        src_fields = list(dict.fromkeys(
            ([time_field] if time_field else [])
            + cve_fields[:15] + msg_fields[:12]
            + ["cve", "title", "description", "summary", "message"]
        ))
        src_fields = [f for f in src_fields if f]

        # Stage 1
        stage1_should = []
        if text_query:
            fields_for_text = list(dict.fromkeys((cve_fields + msg_fields)))[:40]
            stage1_should.append({
                "simple_query_string": {
                    "query": text_query,
                    "fields": fields_for_text if fields_for_text else ["*"],
                    "default_operator": "and"
                }
            })

        q1 = {"bool": {"must": must + stage1_should, "filter": filter_list, "must_not": must_not}}
        body1 = {"query": q1, "size": limit, "track_total_hits": False, "_source": src_fields}
        r1 = await self.tools.run("dsl_search", {"index": pattern, "body": body1, "size": limit})
        if isinstance(r1, dict) and r1.get("count", 0) > 0:
            return {**r1, "stage": "stage1", "time_field_used": time_field}

        # Stage 2
        if text_query:
            fields_for_mm = list(dict.fromkeys((cve_fields + msg_fields)))[:50]
            q2 = {"bool": {"must": must, "filter": filter_list, "must_not": must_not, "should": [
                {"multi_match": {"query": text_query, "fields": fields_for_mm if fields_for_mm else ["*"], "type": "best_fields", "operator": "and"}}
            ], "minimum_should_match": 1}}
            body2 = {"query": q2, "size": limit, "track_total_hits": False, "_source": src_fields}
            r2 = await self.tools.run("dsl_search", {"index": pattern, "body": body2, "size": limit})
            if isinstance(r2, dict) and r2.get("count", 0) > 0:
                return {**r2, "stage": "stage2", "time_field_used": time_field}

        # Stage 3
        if text_query:
            q3 = {"bool": {"filter": filter_list, "must": [
                {"simple_query_string": {"query": text_query, "fields": ["*"], "default_operator": "and"}}
            ]}}
            body3 = {"query": q3, "size": limit, "track_total_hits": False, "_source": src_fields}
            r3 = await self.tools.run("dsl_search", {"index": pattern, "body": body3, "size": limit})
            if isinstance(r3, dict) and r3.get("count", 0) > 0:
                return {**r3, "stage": "stage3", "time_field_used": time_field}

            # Stage 4: drop time
            if include_older and filter_list:
                q4 = {"bool": {"must": [
                    {"simple_query_string": {"query": text_query, "fields": ["*"], "default_operator": "and"}}
                ]}}
                body4 = {"query": q4, "size": limit, "track_total_hits": False, "_source": src_fields}
                r4 = await self.tools.run("dsl_search", {"index": pattern, "body": body4, "size": limit})
                if isinstance(r4, dict) and r4.get("count", 0) > 0:
                    return {**r4, "stage": "stage4_no_time", "time_field_used": time_field}

        return {"index": pattern, "dsl": body1, "count": 0, "hits": [], "stage": "none", "time_field_used": time_field}

    async def run(self, conversation_id: str, user_text: str) -> Tuple[str, Dict[str, Any], List[Dict[str, Any]]]:
        messages = self.store.get(conversation_id)
        if not messages:
            messages = [{"role": "system", "content": SYSTEM_PROMPT}]

        messages.append({"role": "user", "content": user_text})
        messages = _trim_context(messages)

        trace: List[Dict[str, Any]] = []

        # 1) schema-first (tool_call + tool is valid)
        messages, schema_small, pattern, tr = await self._schema_first(messages)
        trace.extend(tr)

        # 2) plan
        plan = await self._plan(user_text, schema_small, pattern)
        trace.append({"step": "plan", "plan": _clip_any(plan)})

        # 3) execute
        artifact = await self._execute_with_fallback(pattern, plan, schema_small)
        trace.append({"step": "execute", "stage": artifact.get("stage"), "time_field_used": artifact.get("time_field_used")})

        # ✅ IMPORTANT FIX:
        # Do NOT inject execution as role='tool' (would require tool_calls). Use assistant text instead.
        artifact_small = _sanitize_tool_result("dsl_search", artifact)
        messages.append({
            "role": "assistant",
            "content": "EXECUTION_RESULT_JSON (use this as evidence):\n" + _clip_text(json.dumps(artifact_small, ensure_ascii=False), MAX_TOOL_MESSAGE_CHARS)
        })
        messages = _trim_context(messages)

        # 4) final summarization
        final_messages = _trim_context(messages + [{
            "role": "system",
            "content": "Now write the final answer using ONLY the evidence in EXECUTION_RESULT_JSON. If count=0, say so clearly."
        }])

        try:
            resp = await self.llm.chat(messages=final_messages)
        except LLMError as e:
            if "context_length_exceeded" in str(e):
                resp = await self.llm.chat(messages=_trim_context(final_messages, max_chars=80_000))
            else:
                raise

        msg = (resp.get("choices") or [{}])[0].get("message") or {}
        answer = msg.get("content") or "(No answer)"

        messages.append({"role": "assistant", "content": answer})
        messages = _trim_context(messages)

        self.store.set(conversation_id, messages)
        return answer, artifact, trace

