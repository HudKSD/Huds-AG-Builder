let conversationId = localStorage.getItem("conversation_id") || null;

const messagesEl = document.getElementById("messages");
const inputEl = document.getElementById("input");
const sendBtn = document.getElementById("send");
const queryUsedEl = document.getElementById("queryUsed");
const tableWrapEl = document.getElementById("tableWrap");

function addMessage(role, content) {
  const div = document.createElement("div");
  div.className = `msg ${role}`;
  div.innerHTML = `
    <div class="role">${role}</div>
    <div class="content"></div>
  `;
  div.querySelector(".content").textContent = content;
  messagesEl.appendChild(div);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function renderTable(columns, rows) {
  if (!columns || !rows) {
    tableWrapEl.innerHTML = "<div class='muted'>No table.</div>";
    return;
  }
  let html = "<table><thead><tr>";
  for (const c of columns) html += `<th>${escapeHtml(c)}</th>`;
  html += "</tr></thead><tbody>";

  for (const r of rows) {
    html += "<tr>";
    for (const cell of r) html += `<td>${escapeHtml(String(cell ?? ""))}</td>`;
    html += "</tr>";
  }
  html += "</tbody></table>";
  tableWrapEl.innerHTML = html;
}

function escapeHtml(str) {
  return str.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
}

async function send() {
  const msg = inputEl.value.trim();
  if (!msg) return;

  addMessage("user", msg);
  inputEl.value = "";

  const resp = await fetch("/api/chat", {
    method: "POST",
    headers: {"Content-Type":"application/json"},
    body: JSON.stringify({message: msg, conversation_id: conversationId})
  });

  const data = await resp.json();

  if (data.conversation_id) {
    conversationId = data.conversation_id;
    localStorage.setItem("conversation_id", conversationId);
  }

  if (data.error) {
    addMessage("assistant", `Error: ${data.error}`);
    return;
  }

  addMessage("assistant", data.answer || "(no answer)");

  // show query + table if available
  const a = data.artifact || {};
  if (a.tool === "esql_query") {
    queryUsedEl.textContent = JSON.stringify({query: a.query, filter: a.filter}, null, 2);
    renderTable(a.columns, a.rows);
  } else if (a.tool === "dsl_search") {
    queryUsedEl.textContent = JSON.stringify({dsl: a}, null, 2);
    tableWrapEl.innerHTML = `<pre class="code">${escapeHtml(JSON.stringify(a.hits || [], null, 2))}</pre>`;
  } else {
    queryUsedEl.textContent = "";
    tableWrapEl.innerHTML = "";
  }
}

sendBtn.addEventListener("click", send);
inputEl.addEventListener("keydown", (e) => {
  if (e.key === "Enter") send();
});

