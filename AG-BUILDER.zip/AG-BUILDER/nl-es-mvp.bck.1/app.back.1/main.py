import logging
from quart import Quart, jsonify, render_template, request
from dotenv import load_dotenv

from elasticsearch import AsyncElasticsearch

from .config import Settings
from .llm_client import OpenAICompatibleClient
from .conversation_store import ConversationStore
from .schema_cache import SchemaCache
from .agent import NL2ESAgent
from .tools.base import ToolContext
from .tools.registry import ToolRegistry
from .tools import ListIndicesTool, GetMappingsTool, EsqlQueryTool, DslSearchTool, GetDocTool

load_dotenv()

app = Quart(__name__)
settings = Settings()

logging.basicConfig(level=getattr(logging, settings.log_level.upper(), logging.INFO))
log = logging.getLogger("nl-es-mvp")

@app.before_serving
async def startup():
    # Elasticsearch client (Basic Auth + TLS verify)
    es_kwargs = {
        "basic_auth": (settings.es_username, settings.es_password),
        "verify_certs": settings.es_verify_certs,
        "request_timeout": settings.es_request_timeout,
    }
    if settings.es_ca_certs:
        es_kwargs["ca_certs"] = settings.es_ca_certs
    if settings.es_ssl_assert_fingerprint:
        es_kwargs["ssl_assert_fingerprint"] = settings.es_ssl_assert_fingerprint

    es = AsyncElasticsearch(settings.es_url, **es_kwargs)

    # Quick connectivity test
    try:
        info = await es.info()
        log.info("Connected to Elasticsearch: %s", (info or {}).get("cluster_name"))
    except Exception as e:
        log.error("Elasticsearch connection failed: %s", e)

    llm = OpenAICompatibleClient(
        base_url=settings.llm_base_url,
        api_key=settings.llm_api_key,
        model=settings.llm_model,
        temperature=settings.llm_temperature,
        max_tokens=settings.llm_max_tokens,
    )

    store = ConversationStore(max_turns=settings.conversation_max_turns)
    schema_cache = SchemaCache(es, settings, ttl_seconds=300)
    ctx = ToolContext(es=es, settings=settings, schema_cache=schema_cache)
    registry = ToolRegistry(ctx)

    # Register tools (extend here)
    registry.register(ListIndicesTool())
    registry.register(GetMappingsTool())
    registry.register(EsqlQueryTool())
    registry.register(DslSearchTool())
    registry.register(GetDocTool())

    agent = NL2ESAgent(llm=llm, tools=registry, store=store, max_steps=settings.max_agent_steps)

    app.config["es"] = es
    app.config["llm"] = llm
    app.config["store"] = store
    app.config["schema_cache"] = schema_cache
    app.config["tools"] = registry
    app.config["agent"] = agent

@app.after_serving
async def shutdown():
    es: AsyncElasticsearch = app.config.get("es")
    llm: OpenAICompatibleClient = app.config.get("llm")
    if es:
        await es.close()
    if llm:
        await llm.close()

@app.get("/")
async def index():
    return await render_template("index.html", allowed_patterns=settings.es_allowed_patterns)

@app.get("/api/health")
async def health():
    es: AsyncElasticsearch = app.config.get("es")
    ok = True
    es_info = {}
    try:
        es_info = await es.info()
    except Exception as e:
        ok = False
        es_info = {"error": str(e)}
    return jsonify({"ok": ok, "es": es_info})

@app.post("/api/chat")
async def chat():
    payload = await request.get_json(force=True)
    user_msg = (payload or {}).get("message", "").strip()
    conversation_id = (payload or {}).get("conversation_id")

    store: ConversationStore = app.config["store"]
    agent: NL2ESAgent = app.config["agent"]

    if not conversation_id:
        conversation_id = store.new_id()

    if not user_msg:
        return jsonify({"error": "Empty message", "conversation_id": conversation_id}), 400

    answer, artifact, trace = await agent.run(conversation_id, user_msg)

    return jsonify({
        "conversation_id": conversation_id,
        "answer": answer,
        "artifact": artifact,   # includes query/filter/table when relevant
        "trace": trace,         # lightweight tool call trace
    })

